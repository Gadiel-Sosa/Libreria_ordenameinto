from .numeros_burbuja import burbuja
from .numeros_insercion import insercion
from .numeros_seleccion import seleccion
from .numeros_heap import heap_sort
from .numeros_quick import quicksort
from .numeros_shell import shellsort
from .numeros_radix import radix_sort