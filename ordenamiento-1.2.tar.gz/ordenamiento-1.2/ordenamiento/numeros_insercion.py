def insercion(lista):
    n = len(lista)
    for i in range(1, n): 
        elemento_a_insertar = lista[i] 
        j = i - 1
        while j >= 0 and lista[j] > elemento_a_insertar:
            lista[j + 1] = lista[j]
            j -= 1
        lista[j + 1] = elemento_a_insertar
        print(f"Iteración {i}: {lista}")
    return lista  # Agregar esta línea para devolver la lista ordenada
